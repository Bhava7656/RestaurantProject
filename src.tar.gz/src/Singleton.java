import java.util.*;

public class Singleton {
    static Singleton singleton = null;
    static Queue<Integer> cooks;
    static Queue<Integer> tables;

    int totalDiners;

    private Singleton() {
        totalDiners = -1;
        cooks = new LinkedList<>();
        tables = new LinkedList<>();
    }

    public static Singleton Singleton() {
        // To ensure only one instance is created
        if (singleton == null) {
            singleton = new Singleton();
        }
        return singleton;
    }

    public int assignCook(){
        return cooks.poll();
    }
    public int assignTable(){
        return tables.poll();
    }

}


