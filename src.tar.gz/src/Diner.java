import java.util.Timer;
import java.util.concurrent.TimeUnit;

class Diner implements Runnable {
    int dinerId;
    int burgerCount;
    int friesCount;
    boolean cokeOrdered;
    int arrivalTime;
    int currentTime;

    Diner(int dinerId, int burgerCount, int friesCount, boolean cokeOrdered, int arrivalTime) {
        this.dinerId = dinerId;
        this.burgerCount = burgerCount;
        this.friesCount = friesCount;
        this.cokeOrdered = cokeOrdered;
        this.arrivalTime = arrivalTime;
        this.currentTime = arrivalTime;
    }

    public static String format(int currentTime) {
        if (currentTime <= 59)
            return String.format("00:%02d", currentTime);

        int hour = currentTime / 60;
        int mins = currentTime % 60;

        return String.format("%02d:%02d", hour, mins);
    }

    @Override
    public void run() {
        try {
            TimeUnit.MILLISECONDS.sleep(arrivalTime * 100);

            System.out.println(String.format("[%s] - Diner %d arrives.", format(currentTime), dinerId));

            long customerStartsWaitTime = System.currentTimeMillis();
            long customerFindTableTime;
            long timeWaitedToGetTable;

            Restaurant.tableSemaphore.acquire();

            customerFindTableTime = System.currentTimeMillis();
            timeWaitedToGetTable = (customerFindTableTime - customerStartsWaitTime) / 100;
            currentTime += timeWaitedToGetTable;

            int tableId = Singleton.Singleton().assignTable();

            System.out.println(String.format("[%s] - Diner %d is seated at Table %d .", format(currentTime), dinerId, tableId));

            Restaurant.cookSemaphore.acquire();
            int cookId = Singleton.Singleton().assignCook();
            System.out.println(String.format("[%s] - Cook %d processes Diner %d's order.", format(currentTime), cookId, dinerId));

            while (burgerCount > 0) {
                long startTime = System.currentTimeMillis();
                long endTime;
                long timeElapsed;
                if (Restaurant.burgerMachineSemaphore.availablePermits() == 0) {

                    if (Restaurant.cokeMachineSemaphore.availablePermits() != 0) {
                        Restaurant.cokeMachineSemaphore.acquire();
                        TimeUnit.MILLISECONDS.sleep(100);
                        System.out.println(String.format("[%s] - Cook %d uses the coke machine.", format(currentTime), cookId));
                        Restaurant.cokeMachineSemaphore.release();
                        cokeOrdered = false;
                    } else if (Restaurant.friesMachineSemaphore.availablePermits() != 0) {
                        Restaurant.friesMachineSemaphore.acquire();
                        TimeUnit.MILLISECONDS.sleep(300);
                        System.out.println(String.format("[%s] - Cook %d uses the fries machine.", format(currentTime), cookId));
                        currentTime += 3;
                        Restaurant.friesMachineSemaphore.release();
                        friesCount--;
                    }
                }
                Restaurant.burgerMachineSemaphore.acquire();
                endTime = System.currentTimeMillis();
                timeElapsed = (endTime - startTime) / 100;
                currentTime += timeElapsed;

                TimeUnit.MILLISECONDS.sleep(500);
                System.out.println(String.format("[%s] - Cook %d uses the burger machine.", format(currentTime), cookId));
                currentTime += 5;
                Restaurant.burgerMachineSemaphore.release();
                burgerCount--;
            }

            while (friesCount > 0) {
                long startTime = System.currentTimeMillis();
                long endTime = 0;
                long timeElapsed = 0;
                if (Restaurant.friesMachineSemaphore.availablePermits() == 0) {

                    if (Restaurant.cokeMachineSemaphore.availablePermits() != 0) {
                        Restaurant.cokeMachineSemaphore.acquire();
                        TimeUnit.MILLISECONDS.sleep(100);
                        currentTime += 1;
                        System.out.println(String.format("[%s] - Cook %d uses the coke machine.", format(currentTime), cookId));
                        Restaurant.cokeMachineSemaphore.release();
                        cokeOrdered = false;
                    }

                    endTime = System.currentTimeMillis();
                    timeElapsed = (endTime - startTime) / 100;
                }
                Restaurant.friesMachineSemaphore.acquire();
                currentTime += timeElapsed;

                TimeUnit.MILLISECONDS.sleep(300);
                System.out.println(String.format("[%s] - Cook %d uses the fries machine.", format(currentTime), cookId));
                currentTime += 3;
                Restaurant.friesMachineSemaphore.release();
                friesCount--;
            }

            if (cokeOrdered) {
                long startTime = System.currentTimeMillis();
                long endTime = 0;
                long timeElapsed = 0;
                if (Restaurant.cokeMachineSemaphore.availablePermits() == 0) {
                    endTime = System.currentTimeMillis();
                    timeElapsed = (endTime - startTime) / 100;
                }
                Restaurant.cokeMachineSemaphore.acquire();
                currentTime += timeElapsed;

                TimeUnit.MILLISECONDS.sleep(100);
                System.out.println(String.format("[%s] - Cook %d uses the coke machine.", format(currentTime), cookId));
                currentTime += 1;
                Restaurant.cokeMachineSemaphore.release();
                cokeOrdered = false;
            }

            System.out.println(String.format("[%s] - Diner %d's order is ready. Diner %d starts eating.", format(currentTime), dinerId, dinerId));
            currentTime += 30;
            TimeUnit.MILLISECONDS.sleep(3000);

            System.out.println(String.format("[%s] - Diner %d finishes. Diner %d leaves the restaurant.", format(currentTime), dinerId, dinerId));

            Restaurant.tableSemaphore.release();
            Restaurant.cookSemaphore.release();

            Singleton.cooks.add(cookId);
            Singleton.tables.add(tableId);

            if (dinerId == Singleton.singleton.totalDiners)
                System.out.println(String.format("[%s] - The last Diner has left the restaurant.", format(currentTime)));


        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}


