PreRequisites: Java 14 or higher.

1. Extract the target file on your machine.
2. Import the src folder to any IDE.
3. The src folder has an input.txt file -> provide your input there.
4. Hit run and output should be visible on the console.

Note: The output printing is in correct format (timestamp : event), but because of machine specific clock these events might not be shown in timestamp sorted order. However all the events will be logged with their correct timestamps.