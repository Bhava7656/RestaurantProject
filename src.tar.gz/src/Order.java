public class Order {
    int startTime;
    int burgerQuantity;
    int friesQuantity;
    int cokeQuantity;

    public Order(int startTime, int burgerQuantity, int friesQuantity, int cokeQuantity) {
        this.startTime = startTime;
        this.burgerQuantity = burgerQuantity;
        this.friesQuantity = friesQuantity;
        this.cokeQuantity = cokeQuantity;
    }
}


