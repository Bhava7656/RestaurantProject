import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class Restaurant {
    static Semaphore tableSemaphore;
    static Semaphore cookSemaphore;
    static Semaphore burgerMachineSemaphore = new Semaphore(1);
    static Semaphore friesMachineSemaphore = new Semaphore(1);
    static Semaphore cokeMachineSemaphore = new Semaphore(1);

    static ArrayList<String> inputList;

    static Input input;

    public static void main(String[] args) {
        File file = new File("src/input.txt");

        try {
            inputList = new ArrayList<>();
            Scanner sc = new Scanner(file);
            while (sc.hasNext()) {
                String i = sc.nextLine();
                inputList.add(i);
            }
            sc.close();
            input = new Input(inputList);

            Singleton singleton = Singleton.Singleton();
            for (int i = 1; i <= input.cookQuantity; i++) singleton.cooks.add(i);
            for (int i = 1; i <= input.tableQuantity; i++) singleton.tables.add(i);

            System.out.println("Logs for Restaurant");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Scanner scanner = new Scanner(System.in);

        int dinerCount = input.dinersQuantity;
        Singleton.singleton.totalDiners = dinerCount;

        int tableCount = input.tableQuantity;
        tableSemaphore = new Semaphore(tableCount);

        int cookCount = input.cookQuantity;
        cookSemaphore = new Semaphore(cookCount);


        System.out.println("Number of diners: " + dinerCount);
        System.out.println("Number of cooks: " + cookCount);
        System.out.println("Number of tables: " + tableCount + "\n");

        for (int i = 0; i < dinerCount; i++) {
            int arrivalTime = input.orders.get(i).startTime;
            int burgerCount = input.orders.get(i).burgerQuantity;
            int friesCount = input.orders.get(i).friesQuantity;
            int cokeOrdered = input.orders.get(i).cokeQuantity;

            new Thread(new Diner(i + 1, burgerCount, friesCount, cokeOrdered == 1, arrivalTime)).start();
        }
        scanner.close();
    }
}


