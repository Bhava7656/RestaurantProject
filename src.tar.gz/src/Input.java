import java.util.ArrayList;

public class Input {
    int dinersQuantity;
    int tableQuantity;
    int cookQuantity;

    ArrayList<Order> orders;

    public Input(ArrayList<String> inputList) {
        dinersQuantity = Integer.parseInt(inputList.get(0));
        tableQuantity = Integer.parseInt(inputList.get(1));
        cookQuantity = Integer.parseInt(inputList.get(2));
        orders = new ArrayList<>();

        for (int i = 3; i < inputList.size(); i++) {
            if(inputList.get(i)!= null) {
                String[] individualOrder = inputList.get(i).split(",");
                Order subOrder = new Order(Integer.parseInt(individualOrder[0]), Integer.parseInt(individualOrder[1]), Integer.parseInt(individualOrder[2]), Integer.parseInt(individualOrder[3]));
                orders.add(subOrder);
            }
            else return;
        }
    }
}


